package com.corhuila.poo.semana2;

class Producto {
public static void main(String[] args) {
    System.out.println("Creación De Objetos");
    Producto p1 = new Producto();
    Producto p2 = new Producto();
    Producto p3 = new Producto();
    System.out.println("p1: " + p1);
    System.out.println("p2: " + p2);
    System.out.println("p3: " + p3);
    System.out.println();

    System.out.println("Referencias");
    Producto p4 = p1; // p4 apunta al mismo objeto que p1
    System.out.println("p1: " + p1);
    System.out.println("p4 (misma referencia que p1): " + p4);
    System.out.println();

    System.out.println("Null");
    Producto pNull = null;
    System.out.println("pNull: " + pNull);
}
}