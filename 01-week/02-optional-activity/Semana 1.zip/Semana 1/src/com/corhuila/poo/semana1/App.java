package com.corhuila.poo.semana1;

public class App {
    public static void main(String[] args) {
        Tarea t1 = new Tarea("Estudiar POO", "Repasar clases y objetos");
        System.out.println(t1.resumen());

        t1.marcarComoHecha();
        System.out.println("Después de marcar como hecha: " + t1.resumen());

        t1.marcarComoPendiente();
        System.out.println("Después de marcar como pendiente: " + t1.resumen());
    }
}
