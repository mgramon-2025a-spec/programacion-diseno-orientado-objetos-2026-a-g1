public class Usuario extends  Persona{
    private String usuario;
    private String contrasena;

    public Usuario (String persona, int telefono, String correo, String usuario, String contrasena) {
        super(persona, telefono, correo);
        this.usuario = usuario;
        this.contrasena = contrasena;
    }

    private void setContrasena(String contrasena) {
    }

    private void setUsuario(String usuario) {
    }

    public String getUsuario () {
        return usuario;
    }
    public String getContrasena () {
        return contrasena;
    }
    public String fichaUsuario() {
        return ficha() + ", Usuario{usuario=" + usuario +" contraseña=" + contrasena;
    }
}
