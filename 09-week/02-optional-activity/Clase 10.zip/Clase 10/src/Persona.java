public class Persona {
    private String persona;
    private int telefono;
    private String correo;

    public Persona (String persona, int telefono, String correo) {
        this.persona =persona;
        this.telefono = telefono;
        this.correo = correo;
    }

    public Persona() {
    }

    public String getPersona () {
        return persona;
    }
    public int getTelefono () {
        return telefono;
    }
    public String getCorreo () {
        return correo;
    }
    public String ficha() {
        return "Persona{persona='" + persona + "', telefono='" + telefono + "', correo=" + correo + "}";
    }
}
