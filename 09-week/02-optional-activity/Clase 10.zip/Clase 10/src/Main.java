public class Main {
    static void main(String[] args) {
        Usuario u = new Usuario ("Lola Ramón", 192767987,"lola.r@gamil.com", "lolara.ar","16627a");
        Persona l = new Persona ("LinaVargas", 243534657, "lina.v@gamil.com");
        System.out.println(u.fichaUsuario());
        System.out.println(l.ficha());
    }
}
