package com.corhuila.poo.taller1;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Producto[] productos = new Producto[5]; // arreglo de 5 productos
        int contador = 0;
        int opcion;

        do {
            System.out.println("\nMENÚ");
            System.out.println("1. Agregar producto");
            System.out.println("2. Listar productos");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1:
                    if (contador >= productos.length) {
                        System.out.println("No se pueden agregar más productos (arreglo lleno).");
                    } else {
                        System.out.print("Ingrese código: ");
                        String codigo = sc.nextLine();
                        System.out.print("Ingrese nombre: ");
                        String nombre = sc.nextLine();
                        System.out.print("Ingrese precio: ");
                        double precio = sc.nextDouble();
                        sc.nextLine();

                        try {
                            productos[contador] = new Producto(codigo, nombre, precio);
                            contador++;
                            System.out.println("Producto agregado correctamente.");
                        } catch (IllegalArgumentException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                    }
                    break;

                case 2:
                    System.out.println("\nLISTA DE PRODUCTOS");
                    for (int i = 0; i < contador; i++) {
                        productos[i].mostrarInfo();
                    }
                    if (contador == 0) {
                        System.out.println("No hay productos registrados.");
                    }
                    break;

                case 3:
                    System.out.println("Saliendo del programa...");
                    break;

                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 3);

        sc.close();
    }
}