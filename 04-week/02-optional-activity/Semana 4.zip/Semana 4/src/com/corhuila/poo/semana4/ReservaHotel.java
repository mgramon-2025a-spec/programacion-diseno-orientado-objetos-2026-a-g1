package com.corhuila.poo.semana4;

public class ReservaHotel {
    private final String codigo;
    private final String nombreHuesped;
    private final int noches;
    private final double valorNoche;
    private final boolean incluyeDesayuno;

    public ReservaHotel(String codigo, String nombreHuesped, int noches, double valorNoche, boolean incluyeDesayuno) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío.");
        }
        if (nombreHuesped == null || nombreHuesped.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del huésped no puede estar vacío.");
        }
        if (noches <= 0) {
            throw new IllegalArgumentException("Las noches deben ser mayores a 0.");
        }
        if (valorNoche <= 0) {
            throw new IllegalArgumentException("El valor por noche debe ser mayor a 0.");
        }
        this.codigo = codigo.trim();
        this.nombreHuesped = nombreHuesped.trim();
        this.noches = noches;
        this.valorNoche = valorNoche;
        this.incluyeDesayuno = incluyeDesayuno;
    }

    public ReservaHotel(String codigo, String nombreHuesped, int noches, double valorNoche) {
        this(codigo, nombreHuesped, noches, valorNoche, false);
    }

    @Override
    public String toString() {
        double total = noches * valorNoche;
        return "ReservaHotel{" +
                "codigo='" + codigo + '\'' +
                ", huesped='" + nombreHuesped + '\'' +
                ", noches=" + noches +
                ", valorNoche=" + valorNoche +
                ", total=" + total +
                ", incluyeDesayuno=" + incluyeDesayuno +
                '}';
    }

    static void main() {
        System.out.println("Reserva 1 (con desayuno)");
        ReservaHotel r1 = new ReservaHotel("R-001", "Camila", 3, 120000, true);
        System.out.println(r1);
        System.out.println();

        System.out.println("Reserva 2 (sin desayuno, constructor alterno)");
        ReservaHotel r2 = new ReservaHotel("R-002", "Andrés", 2, 95000);
        System.out.println(r2);
        System.out.println();

        System.out.println("Reserva 3 (otra prueba)");
        ReservaHotel r3 = new ReservaHotel("R-003", "María", 5, 150000, false);
        System.out.println(r3);
    }
}