package com.corhuila.poo.semana9.contracts;

public interface Asegurable {
    double calcularSeguro();
}
