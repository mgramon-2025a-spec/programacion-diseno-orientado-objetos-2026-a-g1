package com.corhuila.poo.semana9.app;

import com.corhuila.poo.semana9.envios.*;
import com.corhuila.poo.semana9.model.*;

public class App {
    public static void main(String[] args) {
        Cliente c1 = new Cliente("1", "María González", "NORMAL");
        Cliente c2 = new Cliente("2", "Carlos Pérez", "FRECUENTE");

        Envio e1 = new EnvioEstandar("E001", 2, 50);
        Envio e2 = new EnvioExpress("E002", 5, 100);
        Envio e3 = new EnvioInternacional("E003", 10, 1500, "España");

        OrdenEnvio o1 = new OrdenEnvio(c1, e2, "2026-04-21");
        OrdenEnvio o2 = new OrdenEnvio(c2, e3, "2026-04-21");

        System.out.println(o1.detalle());
        System.out.println(o2.detalle());
    }
}
