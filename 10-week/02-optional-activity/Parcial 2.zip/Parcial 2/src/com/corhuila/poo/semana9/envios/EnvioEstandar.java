package com.corhuila.poo.semana9.envios;

public class EnvioEstandar extends Envio {
    public EnvioEstandar(String codigo, double pesoKg, double distanciaKm) {
        super(codigo, pesoKg, distanciaKm);
    }

    @Override
    public double calcularCostoBase() {
        return 5000 + (getPesoKg() * 1000) + (getDistanciaKm() * 200);
    }
}
