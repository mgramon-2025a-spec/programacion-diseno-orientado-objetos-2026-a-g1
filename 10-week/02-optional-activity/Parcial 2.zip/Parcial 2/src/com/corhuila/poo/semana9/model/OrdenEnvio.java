package com.corhuila.poo.semana9.model;
import com.corhuila.poo.semana9.envios.Envio;

public class OrdenEnvio {
    private Cliente cliente;
    private Envio envio;
    private String fecha;

    public OrdenEnvio(Cliente cliente, Envio envio, String fecha) {
        this.cliente = cliente;
        this.envio = envio;
        this.fecha = fecha;
    }

    public double total() {
        double base = envio.calcularCostoTotal();
        if (cliente.getTipo().equalsIgnoreCase("FRECUENTE")) {
            base *= 0.9; // 10% descuento adicional
        }
        return base;
    }

    public String detalle() {
        return "Orden: Cliente=" + cliente.getNombre() + ", Tipo=" + cliente.getTipo() +
                ", Envio=" + envio.resumen() + ", Total=" + total();
    }
}
