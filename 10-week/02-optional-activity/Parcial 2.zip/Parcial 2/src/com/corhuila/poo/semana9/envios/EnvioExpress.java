package com.corhuila.poo.semana9.envios;

import com.corhuila.poo.semana9.contracts.Asegurable;

public class EnvioExpress extends Envio implements Asegurable {
    public EnvioExpress(String codigo, double pesoKg, double distanciaKm) {
        super(codigo, pesoKg, distanciaKm);
    }

    @Override
    public double calcularCostoBase() {
        return 10000 + (getPesoKg() * 2000) + (getDistanciaKm() * 400);
    }

    @Override
    public double calcularSeguro() {
        return calcularCostoBase() * 0.1; // 10% del costo base
    }
}
