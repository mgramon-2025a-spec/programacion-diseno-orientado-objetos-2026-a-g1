package com.corhuila.poo.semana9.contracts;

public interface Descontable {
    double calcularDescuento();
}

