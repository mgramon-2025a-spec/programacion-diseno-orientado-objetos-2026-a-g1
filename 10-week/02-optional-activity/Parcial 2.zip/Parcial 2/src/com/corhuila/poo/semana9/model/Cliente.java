package com.corhuila.poo.semana9.model;

public class Cliente {
    private String id;
    private String nombre;
    private String tipo; // NORMAL, FRECUENTE, EMPRESA

    public Cliente(String id, String nombre, String tipo) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
    }

    public String getNombre() { return nombre; }
    public String getTipo() { return tipo; }
}
