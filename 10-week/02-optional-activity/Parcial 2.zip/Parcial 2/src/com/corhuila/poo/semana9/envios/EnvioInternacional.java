package com.corhuila.poo.semana9.envios;

import com.corhuila.poo.semana9.contracts.Descontable;

public class EnvioInternacional extends Envio implements Descontable {
    private String paisDestino;

    public EnvioInternacional(String codigo, double pesoKg, double distanciaKm, String paisDestino) {
        super(codigo, pesoKg, distanciaKm);
        this.paisDestino = paisDestino;
    }

    @Override
    public double calcularCostoBase() {
        return 30000 + (getPesoKg() * 5000) + (getDistanciaKm() * 1000);
    }

    @Override
    public double calcularDescuento() {
        if (getDistanciaKm() > 1000) {
            return 5000; // descuento fijo
        }
        return 0;
    }

    @Override
    public String resumen() {
        return super.resumen() + " -> Destino: " + paisDestino;
    }
}

