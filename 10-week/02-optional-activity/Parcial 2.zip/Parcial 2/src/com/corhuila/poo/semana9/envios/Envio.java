package com.corhuila.poo.semana9.envios;

import com.corhuila.poo.semana9.contracts.Asegurable;
import com.corhuila.poo.semana9.contracts.Descontable;

public abstract class Envio {
    private String codigo;
    private double pesoKg;
    private double distanciaKm;

    public Envio(String codigo, double pesoKg, double distanciaKm) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("Código inválido.");
        }
        if (pesoKg <= 0 || distanciaKm <= 0) {
            throw new IllegalArgumentException("Peso y distancia deben ser > 0.");
        }
        this.codigo = codigo;
        this.pesoKg = pesoKg;
        this.distanciaKm = distanciaKm;
    }

    public String getCodigo() { return codigo; }
    public double getPesoKg() { return pesoKg; }
    public double getDistanciaKm() { return distanciaKm; }

    public abstract double calcularCostoBase();

    public double calcularCostoTotal() {
        double base = calcularCostoBase();
        double extras = 0;

        if (this instanceof Asegurable) {
            extras += ((Asegurable) this).calcularSeguro();
        }
        if (this instanceof Descontable) {
            extras -= ((Descontable) this).calcularDescuento();
        }

        return base + extras;
    }

    public String resumen() {
        return "Envio{" + codigo + ", peso=" + pesoKg + "kg, distancia=" + distanciaKm + "km}";
    }
}