package com.corhuila.poo.semana3;

public class TarjetaTransporte {
    // Atributos privados
    private String codigo;
    private double saldo;
    private boolean activa;

    // Constructor
    public TarjetaTransporte(String codigo, double saldoInicial) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío.");
        }
        if (saldoInicial < 0) {
            throw new IllegalArgumentException("El saldo inicial no puede ser negativo.");
        }
        this.codigo = codigo.trim();
        this.saldo = saldoInicial;
        this.activa = true;
    }

    public void recargar(double monto) {
        if (monto <= 0) {
            System.out.println("El monto debe ser mayor a 0.");
            return;
        }
        saldo += monto;
        System.out.println("Recarga exitosa. Saldo actual: " + saldo);
    }

    public void pagarPasaje(double valorPasaje) {
        if (!activa) {
            System.out.println("La tarjeta está desactivada.");
            return;
        }
        if (valorPasaje <= 0) {
            System.out.println("El valor del pasaje debe ser mayor a 0.");
            return;
        }
        if (saldo < valorPasaje) {
            System.out.println("Saldo insuficiente.");
            return;
        }
        saldo -= valorPasaje;
        System.out.println("Pasaje pagado. Saldo restante: " + saldo);
    }

    public void activar() {
        activa = true;
        System.out.println("Tarjeta activada.");
    }

    public void desactivar() {
        activa = false;
        System.out.println("Tarjeta desactivada.");
    }

    public double getSaldo() {
        return saldo;
    }

    public String resumen() {
        return "TarjetaTransporte{codigo='" + codigo + "', saldo=" + saldo + ", activa=" + activa + "}";
    }

    public static void main(String[] args) {
        TarjetaTransporte t1 = new TarjetaTransporte("T-001", 5000);

        System.out.println("Estado Inicial");
        System.out.println(t1.resumen());
        System.out.println();

        System.out.println("Recarga");
        t1.recargar(2000);
        System.out.println(t1.resumen());
        System.out.println();

        System.out.println("Pago De Pasaje");
        t1.pagarPasaje(2500);
        System.out.println(t1.resumen());
        System.out.println();

        System.out.println("Pago Sin Saldo");
        t1.pagarPasaje(10000);
        System.out.println(t1.resumen());
        System.out.println();

        System.out.println("Desactivar Y Probar Pago");
        t1.desactivar();
        t1.pagarPasaje(2000);
        System.out.println(t1.resumen());
    }
}