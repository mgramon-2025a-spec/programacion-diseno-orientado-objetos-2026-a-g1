package com.corhuila.poo.Semana8;

class Bus extends Vehiculo{
    private int numeroPasajeros;

    public Bus (String marca, int velocidadMaxima, int numeroPasajeros) {
        super(marca, velocidadMaxima);
        this.numeroPasajeros = numeroPasajeros;
    }
    @Override
    public String moverse () {
        return "El bus avanza por la ruta con 40 pasajeros.";
    }
}
