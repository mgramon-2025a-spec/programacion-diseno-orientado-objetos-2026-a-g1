package com.corhuila.poo.Semana8;
public class Principal {
    static void main(String[] args) {
        System.out.println("                           **Sistema de Transporte**");
        Vehiculo [] vehiculos ={
                new Bicicleta("TRLpro", 60),
                new Bus("Coomotor", 80,20),
                new Moto("Honda", 100)
        };
        System.out.println("        *Info de vehiculos*");
        for (Vehiculo a: vehiculos){
            a.informacion();
            System.out.println();
        }
        System.out.println("        *Vehiculos privados*");
        for (Vehiculo a : vehiculos) {
            if (a instanceof Propietario) {
                Propietario d = (Propietario) a;
                d.mostrarPropietario("Gabriela Ramón");
            }
        }
        System.out.println("        **FIN*+");
    }
}
