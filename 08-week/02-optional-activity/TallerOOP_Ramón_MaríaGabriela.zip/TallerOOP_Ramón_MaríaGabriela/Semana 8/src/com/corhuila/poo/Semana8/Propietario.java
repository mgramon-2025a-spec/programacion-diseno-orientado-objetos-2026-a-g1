package com.corhuila.poo.Semana8;

public interface Propietario {
    void mostrarPropietario (String dueno);
}