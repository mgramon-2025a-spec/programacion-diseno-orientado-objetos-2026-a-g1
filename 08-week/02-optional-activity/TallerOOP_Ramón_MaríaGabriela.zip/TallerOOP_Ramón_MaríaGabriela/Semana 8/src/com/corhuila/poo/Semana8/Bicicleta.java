package com.corhuila.poo.Semana8;

class Bicicleta extends Vehiculo implements Propietario {

    public Bicicleta (String marca, int velocidadMaxima) {
        super (marca, velocidadMaxima);
    }
    @Override
    public String moverse() {
        return "La bicicleta pedala por el carril bici.";
    }
    @Override
    public void mostrarPropietario (String dueno) {
        System.out.println("la Bicicleta "+getMarca()+"es propiedad de "+ dueno);
    }

}
