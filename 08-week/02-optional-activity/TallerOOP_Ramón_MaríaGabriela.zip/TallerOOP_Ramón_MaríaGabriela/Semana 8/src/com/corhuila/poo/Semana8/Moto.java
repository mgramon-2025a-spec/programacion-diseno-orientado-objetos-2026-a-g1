package com.corhuila.poo.Semana8;

class Moto extends Vehiculo implements Propietario{

    public Moto (String marca, int velocidadMaxima) {
        super(marca, velocidadMaxima);
    }
    @Override
    public String moverse () {
        return "La moto acelera a toda velocidad.";
    }
    @Override
    public void mostrarPropietario (String dueno) {
        System.out.println("la Moto "+getMarca()+"es propiedad de "+ dueno);
    }
}