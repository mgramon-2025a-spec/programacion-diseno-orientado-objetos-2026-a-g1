package com.corhuila.poo.Semana8;

abstract class Vehiculo {
    private String marca;
    private int velocidadMaxima;

    public Vehiculo (String marca, int velocidadMaxima) {
        this.marca =   marca;
        this.velocidadMaxima = velocidadMaxima;
    }

    public String getMarca() {
        return marca;
    }

    public int getVelocidadMaxima() {
        return velocidadMaxima;
    }
    public abstract String moverse();
    public void informacion() {
        System.out.println("Este vehiculo es de la marca: "+marca+
                "|| la velocidad maxima es: "+velocidadMaxima);
        System.out.println(" Se mueve de esta forma: "+moverse());
    }
}
