// Ave: solo hereda de Animal, agrega habilidad especial
class Ave extends Animal {
    private boolean puedeVolar;

    public Ave(String nombre, int edad, boolean puedeVolar) {
        super(nombre, edad);
        this.puedeVolar = puedeVolar;
    }

    @Override
    public String hacerSonido() { return "¡Pío pío!"; }

    public void volar() {
        if (puedeVolar)
            System.out.println(getNombre() + " está volando 🐦");
        else
            System.out.println(getNombre() + " no puede volar.");
    }
}