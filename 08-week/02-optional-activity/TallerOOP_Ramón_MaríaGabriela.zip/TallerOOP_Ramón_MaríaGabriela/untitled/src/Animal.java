// Clase abstracta: define la estructura, no se instancia directa
abstract class Animal {
    private String nombre;
    private int    edad;
    // Constructor: inicializa los atributos comunes
    public Animal(String nombre, int edad) {
        this.nombre = nombre;
        this.edad   = edad;
    }
    // Getters — encapsulamiento
    public String getNombre() { return nombre; }
    public int    getEdad()   { return edad; }
    // Método abstracto: OBLIGA a las subclases a implementarlo
    public abstract String hacerSonido();
    // Método concreto: se hereda tal cual
    public void presentarse() {
        System.out.println("Hola, soy " + nombre +
                ", tengo " + edad + " años.");
        System.out.println("Mi sonido es: " + hacerSonido());
    }
}