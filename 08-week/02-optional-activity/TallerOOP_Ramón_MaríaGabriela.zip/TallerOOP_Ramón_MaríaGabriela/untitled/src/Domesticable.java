interface Domesticable {
    // Solo la firma — sin implementación
    void mostrarDueno(String dueno);
}