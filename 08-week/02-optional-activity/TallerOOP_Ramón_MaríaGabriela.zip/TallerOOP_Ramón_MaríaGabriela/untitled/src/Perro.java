// Perro: hereda de Animal e implementa Domesticable
class Perro extends Animal implements Domesticable {
    private String raza;
    public Perro(String nombre, int edad, String raza) {
        super(nombre, edad); // llama al constructor de Animal
        this.raza = raza;
    }
    @Override
    public String hacerSonido() { return "¡Guau guau!"; }
    @Override
    public void mostrarDueno(String dueno) {
        System.out.println(getNombre() + " pertenece a " + dueno);
    }
}
