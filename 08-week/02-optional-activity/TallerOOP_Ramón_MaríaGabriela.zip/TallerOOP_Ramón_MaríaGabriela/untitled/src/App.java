class EjemploHerencia {
    public static void main(String[] args) {
        System.out.println("=== TALLER: Herencia y Polimorfismo ===\n");
        // Polimorfismo: array de tipo Animal, objetos de distinto tipo real
        Animal[] animales = {
                new Perro("Firulais", 3, "Labrador"),
                new Gato("Mishi", 2),
                new Ave("Piolín", 1, true)
        };
        System.out.println("--- Presentación de animales ---");
        for (Animal a : animales) {
            a.presentarse(); // polimorfismo: cada uno llama su hacerSonido()
            System.out.println();
        }
        System.out.println("--- Animales domésticos ---");
        for (Animal a : animales) {
            if (a instanceof Domesticable) {
                Domesticable d = (Domesticable) a;
                d.mostrarDueno("Juan Pérez");
            }
        }
        System.out.println("\n--- Habilidades especiales ---");
        Ave ave = new Ave("Tweety", 1, false);
        ave.volar();
        System.out.println("\n=== Fin del taller ===");
    }
}
