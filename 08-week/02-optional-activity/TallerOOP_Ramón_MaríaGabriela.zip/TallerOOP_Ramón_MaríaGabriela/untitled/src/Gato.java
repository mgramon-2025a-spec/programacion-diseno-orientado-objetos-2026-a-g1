// Gato: hereda de Animal e implementa Domesticable
class Gato extends Animal implements Domesticable {
    public Gato(String nombre, int edad) {
        super(nombre, edad);
    }

    @Override
    public String hacerSonido() { return "¡Miau miau!"; }

    @Override
    public void mostrarDueno(String dueno) {
        System.out.println(getNombre() + " vive con " + dueno);
    }
}