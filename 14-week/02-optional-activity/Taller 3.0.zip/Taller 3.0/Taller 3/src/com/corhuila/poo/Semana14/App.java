package com.corhuila.poo.Semana14;

import java.util.Scanner;
public class App {
    public static void main (String [] args) {
        Scanner sc = new Scanner (System.in);
        Agenda agenda = new Agenda ();
        int opcion = 0;
        do {
            System.out.println ("\n Menu De Los Contactos");
            System.out.println ("1.Agregar contacto");
            System.out.println ("2.Buscar contacto");
            System.out.println ("3.Listar contactos");
            System.out.println ("4.Eliminar contacto");
            System.out.println ("5.Salir");
            System.out.print ("Opción: ");
            try {
                opcion = Integer.parseInt (sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println ("Debes escribir un número");
                continue;
            }
            if (opcion == 1) {
                try {
                    System.out.print ("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print ("Teléfono: ");
                    String tel = sc.nextLine();
                    Contacto c = new Contacto (nombre, tel);
                    if (agenda.agregar(c)) {
                        System.out.println ("Contacto guardado.");
                    } else {
                        System.out.println ("Ese nombre ya existe.");
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println ("Error: " + e.getMessage());
                }
            } else if (opcion == 2) {
                System.out.print ("Nombre a buscar: ");
                String buscar = sc.nextLine();
                String tel = agenda.buscar(buscar);
                if (tel != null) {
                    System.out.println (buscar + " - " + tel);
                } else {
                    System.out.println ("No encontré ese contacto");
                }
            } else if (opcion == 3) {
                agenda.mostrar();
            } else if (opcion == 4) {
                System.out.print ("Nombre a eliminar: ");
                String borrar = sc.nextLine();
                if (agenda.eliminar (borrar)) {
                    System.out.println ("Contacto eliminado.");
                } else {
                    System.out.println ("No existe.");
                }
            } else if (opcion == 5) {
                System.out.println ("Saliendo del programa...");
            } else {
                System.out.println ("Opción inválida.");
            }
        } while (opcion != 5);
        sc.close();
    }
}
