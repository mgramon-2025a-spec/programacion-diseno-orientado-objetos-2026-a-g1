package com.corhuila.poo.Semana14;

public class Contacto {
private String nombre;
private String telefono;
public Contacto (String nombre, String telefono) {
    if (nombre == null || nombre.trim ().isEmpty ()) {
        throw new IllegalArgumentException ("El nombre no puede estar vacío");
    }
    if (telefono == null || telefono.trim ().isEmpty()) {
        throw new IllegalArgumentException ("El teléfono no puede estar vacío");
    }
    this.nombre = nombre.trim();
    this.telefono = telefono.trim();
}
public String getNombre () {
    return nombre;
}
public  String getTelefono () {
    return telefono;
}
@Override
    public  String toString () {
    return nombre + " - " + telefono;
}
}
