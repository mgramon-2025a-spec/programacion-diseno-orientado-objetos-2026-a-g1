package com.corhuila.poo.Semana14;

import java.util.HashMap;

public class Agenda {
    private HashMap <String, String> contactos;
    public Agenda () {
        contactos = new HashMap <> ();
    }
    public boolean agregar (Contacto c) {
        if (contactos.containsKey (c.getNombre ())) {
            return false;
        }
        contactos.put (c.getNombre (), c.getTelefono ());
        return true;
    }
    public String buscar (String nombre) {
        return contactos.get (nombre);
    }
    public void mostrar () {
        if (contactos.isEmpty ()) {
            System.out.println("No hay contactos");
        } else {
            for (String n : contactos.keySet ()) {
                System.out.println("El nombre es:" + n + "El teléfono:" + contactos.get (n));
            }
        }
    }
    public boolean eliminar (String nombre) {
        if (contactos.containsKey ((nombre))) {
            contactos.remove (nombre);
            return true;
        }
        return false;
    }
}
